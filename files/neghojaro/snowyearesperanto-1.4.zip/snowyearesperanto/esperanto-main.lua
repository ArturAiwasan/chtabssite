game.act = 'Ghi ne funkcias.';
game.inv = 'Gm.. Stranga afero..';
game.use = 'Ne funkcias.';



require "snd"
require "noinv"
require "cutscene"

function init()
end;

global {
step = 0;
};

obj {
 nam = 'tik';
 disp = 'Horlogho';
 inv = 'Horlogo. Bedaurinde, la Pilko ne memoras, kiam li achetis ilin.';
}

obj {
 nam = 'art';
 disp = 'Kelkaja afero';
 inv = 'Kelkaj brila seslatero la grandeco de la palmo kaj la bildo de la arbo de Kristnasko.';
}


room {
 snd.music 'mus/01_space_light.it';
 nam = 'esperantomain';
 title = 'Komenco';
 enter = function(s)
    theme.set("scr.gfx.bg", "theme/bg.png");
	take 'tik'
	end;
 way = {path{'обзор', 'Vidi la luno', 'view'}:disable(), path{'идти', 'Iru al la klifo', 'lvl1'}:disable()};
	dsc = [[Vintro... La negho kraketoj agrable sub viaj piedoj.]];
	decor = [[La Pilko staras proksime al la barilo en negho-kovrita parko, lokita proksime de la malgranda {#утес|rock}. For, de la nuboj de la chielo, vi povas vidi la blankan {#луна|Luno}.]];
 }:with{
obj {
 nam = '#утес';
 act = 'La supro de la krutajo ekstaras alta super la tero.';
 };
obj {
 nam = '#луна';
 act = function(s)
 if visited('esperantomain') then
 p 'Shajnis al mi, sed la boacoj jungita al la sledo preterflugis la luno.';
 enable 'обзор';
 if visited('view') then 
 disable 'обзор'
 end;
 end;
end;
};
}

room {
 noinv = true;
 nam = 'view';
 title = 'Rigardanta la luno...';
 dsc = 'Beleco!^Pilko, rigardante al la luno, samtempe provante vidi por al boacoj.';
 decor = '^Subite! La Pilko avizoj verda lumo en la distanco, malantau la klifo. ^"Ghi devas esti Patro Kristnasko!" - pensis Pilko. ^Nun la Pilko havas celon - {@ walk esperantomain|atingeblaj} al verda brilo malproksime sur la horizonto.';
 onexit = function(s)
 disable 'обзор';
 enable 'идти';
 end;
};

room {
 nam = 'lvl1';
 title = 'Che la enirejo al la parko';
 dsc = 'La Pilko staras de la enirejo al la parko.';
 way = {path{'#inleft', 'Iri al la vendejo', 'store'}:disable(), path{'#inright', 'Iri laulonge de la autoveturejo', 'road'}:disable()};
 decor = 'Malrapide falas {#snow|negho}.^ {#lamp|Lumoj} lau la vojoj lumigi la vojon de malofte pasanta to kaj {#t|passers}, dezirante rapide akiras hejme por la ferioj. Vi povas marshi sur la trotuaro {#left|maldekstre} de la enirejo al la Parko, iranta al la plej proksima papervendejo, au {#right|prave}, en la direkto de la vojo iranta ekstere de la urbo.';
}:with{
 obj {
  nam = '#snow';
  act = 'Chiu neghero kontribuas al la kreo de neghamaso.';
 };
 obj {
  nam = '#lamp';
  act = '"Mesaghistoj de lumo sur la vojo!" - hehe.';
 };
 obj {
  nam = '#t';
  act = 'Ah! Ili estas atendanta en hejmo, kaj mi estas sur mia propra...';
 };
 obj {
  nam = '#left';
  act = function(s)
  enable '#inleft';
  end;
 };
 obj {
  nam = '#right';
  act = function(s)
  enable '#inright';
  end;
  };
}

room {
 nam = 'store';
 title = 'En la vendejo';
 enter = function(s)
 snd.music 'mus/hybrids.xm';
 p 'Mi iris en la butiko.';
end;
onenter = function(s)
if visited('pack') then 
walk 'store2';
p '^Tie estas neniu punkto en eniranta la vendejo. Mono neniu.';
else
end;
end;
 way = {path{'Lasi la vendejo', 'store2'}};
 decor = 'En la papervendejo vi povas esti in utila.^Malantau la vendotablo de la vendisto estas {#female|saleswoman}.';
 }:with{
 obj {
  nam = '#female';
  act = function(s)
  p 'Dum la tempo kiam mi vizitis chi tiun butikon, mi ne vidis chi tiun vendistino. ^Povas esti al ghi {#femaledlg|bonvolu raporti} por la dekstra varoj.';
 end;
 };
 obj {
  nam = '#femaledlg';
  act = function(s)
  walk 'infemaledlg'
  end;
  };
 };
 
dlg { 
  nam = 'infemaledlg';
  noinv = true;
  title = [[Konversacio kun la vendistino]];
  enter = [[Mi turnis al la vendistino]];
  phr = {
      {'Saluton! Chu vi povas havigi al la tuta listo de papervendejo?', function(s) walk 'pack' end};
	  };
	  
}	  
room {
 noinv = true;
 nam = 'pack';
 title = 'Listo de varoj';
 way = {path{'Doni listo de produktoj', 'store'}};
 dsc = 'La vendistino donis al mi la tuta listo de varoj. De chiuj la bonoj mi provizis la usta ones:';
 decor = '^{#n|Tondilo}  -- 50 moneroj^{#r|Krajono} -- 5 moneroj^{#t|Kajero en kagho} -- 5 moneroj^{#b|Malgranda baterio} -- 30 moneroj';
 }:with{
 obj {
  nam = '#n';
  act = 'Mi anta ol elektanta la tondiloj, rigardis la enhavon de mia monujo - malplena! Por meti ghin milde, mi estas chagrenita.';
 };
 obj {
  nam = '#r';
  act = 'Mi anta ol elektanta la krajono, rigardis la enhavon de mia monujo - malplena! Por meti ghin milde, mi estas chagrenita.';
 };
 obj {
  nam = '#t';
  act = 'Mi anta ol elektanta la kajero en kagho, rigardis la enhavon de mia monujo - malplena! Por meti ghin milde, mi estas chagrenita.';
 };
 obj {
  nam = '#b';
  act = 'Mi anta ol elektanta la batareioj, rigardis la enhavon de mia monujo - malplena! Por meti ghin milde, mi estas chagrenita.';
 };
 
};

room {
 nam = 'store2';
 title = 'Proksime de la vendejo';
 enter = function(s)
 snd.music 'mus/01_space_light.it';
 end;
 way = {path{'Eniro la vendejo','store'}};
 onenter = function(s)
 if visited('pack') then
 p 'Mi eliris seniluziigita. Kiamaniere mi ne rimarkos la mankon de mono?';
 else
 p 'Mi lasis la vendejo.';
end;
end;
dsc = 'Negho kiel kaj antaue malrapide falas pri trotuaroj, vojoj, domoj kaj butikoj.';
decor = function(s)
if visited('pack') then 
p 'Mi staras ekster la vendejo. La nura afero mi povas fari, {@ walk road|iri} kune la autoveturejo por ke videbla brilanta lumo sur la horizonto.';
else
p 'Mi staras ekster la butiko. Mi pensas, ke mi volis acheti ion...';
end;
end;
};

room {
 nam = 'road';
 title = 'Vojo';
 onenter = 'Deca distanco restas por iri al la falinta objekto. Se nur mi povus trovi taksion! Sed estas neniu, kiu estas, ni devas piediri. La malvarmo ne ghenas min.';
 dsc = 'La vojo, lumigita de lanternoj kaj kovrita de negho, aspektas bela. La negho shajnas esti fali eĉ pli rapide. Mi devas {@ walk road2|iri daurighi}.';
}

cutscene {
 nam = 'road2';
 title = '???';
 decor = function()
 p '^Subite. En momento la vento ululis, kaj kun tia forto, ke Pilko estis jetita al la flanko de La vojo. [cut]';
 p '^ Pilko devas ellitighi! La neĝo ŝajnas bruli mia vizaĝo. La Pilko ne povas movi. [cut]';
 p '^ Nenio helpas! Chiun fojon, kiam la Pilko venas al ia piedoj, la vento denove kiel sorto estus lin sur la asfalto, kovrita kun malgranda tavolo de negho. Tio ne faras ghin ajna pli facila, tamen. [cut]';
 p '^ Kion fari?[cut]';
 p '^ La Pilko forlasis la vojon kaj kashis sin malantau proksima Arbusto [cut]';
 p '^[walk lvl2]';
 remove 'tik'
 end;
 };
 
room {
 nam = 'lvl2';
 title = 'Proksime de forlasita fabriko';
 way = {path{'#sv','Iras al la rubejo', 'xlam'}:disable(), path{'#fab', 'Eniri en la teritorio de la fabriko', 'fabricaroom'}:disable()};
 dsc = 'La Pilko malrapide malfermis la okulojn. La negho estis ankorau falante, sed ne tiel malfacile. Li volis rigardi sian horloghon, sed ghi ne estis tie! ^Kiel do? Li estas tre chagrenita...^rezultis, ke la Pilko estas havi kelkaj fabrikoj. Kaj vi povas diri al de la rigardo de ghi ke ghi estas forlasita. Nur kiel la Pilko estis che la fabriko?';
 decor = 'Ghi estas kvieta mallumo. La negho estas falo malrapide... La Pilko estas pri forlasita {#fabriki|fabrikoj}. Proksime, malantau la {#sva|rubejo} (kiel li konjektis de la skeletoj de la mashinoj), li vidas, ke verda brilo!';
}:with{
 obj {
  nam = '#sva';
  act = function(s)
  enable '#sv'
  p 'Ne malproksime de la fabriko. Sed la distanco estas grava. Ghi estas bona ke la luno iel administras la lumo la vojo por mi.';
  end;
 };
 obj {
  nam = '#fabriki';
  act = function(s)
  enable '#fab'
  p 'La fumo turoj de la fabriko estas kashita en la nokta mallumo, kaj la fluo de negho. Povas iri kaj rigardi kio.';
  end;
 };
};

room {
 nam = 'fabricaroom';
 title = 'La teritorio de la fabriko';
 way = {path{'Iri eksteren', 'lvl2'}};
 dsc = 'La tuta teritorio de la fabriko estas kovrita per negho. Vi devas esti zorgema, sub la negho povas esti io ajn.';
 decor = 'Tuj malantau mi estas la malfermaj kradoj. Kelkaj metroj de la pordego estas {#fabricii|fabriko konstruajo}. Lau la signo la pordego, tio estas fabrikado fabriko... Traktoroj? Mi ne memoras havanta fabriko proksime de la urbo.^Ankau, se vi iros dekstren, vi povas akiri al {#sc|la staplo}.';
}:with{
 obj {
  nam = '#sc';
  act = 'Mi iris al la masiva kaj grandaj pordoj de la magazeno kaj provis malfermi ilin, sed sen sukceso. Aspektas kiel la pordoj estas fermitaj.';
 };
 obj {
  nam = '#fabricii';
  act = 'Mi iris al la ligna kaj putra - rigardanta antaŭ pordoj de la fabriko kaj tiris la malvarma metalo anso de la sama pordo. Sed ghi ne estas malfermita. Nek sur sin, nek interne. Mi provis frapi ghin ekstere, sed neniu. Nenio funkcias.';
 };
 obj {
  nam = 'sugrob';
  dsc = 'Ĉe la pordego estas tre grandaj {snowdrift}.';
  act = function(s)
  if not have 'art' then
   pl.obj:add('art')
   p 'Mi furiozis en la negho kaj trovis ion brilan aferon.';
 else 
 p 'Mi furiozis en la negho, sed trovis nenion.'
 end;
 end;
 };
}

room {
 nam = 'xlam';
 title = 'Rubejo';
 dsc = 'Pilko certa, sed kvieta pasho, eniris la teritorion de la entombigo. ^^Tre iomete-iomete restis!';
 decor = 'La Pilko devas {#step|iri} sur negho kovrita rubejo.';
}:with{
 obj {
  nam = '#step';
  dsc = function(s) p ('La Pilko pasis: '..step..''); end;
  act = function(s)
  if step ~= 5 then
  step = step + 1
  else
  walk 'lvl3'
  end;
  end;
  }
};

room {
 nam = 'lvl3';
 title = 'Proksime de la krashis sledge';
 enter = 'Kaj jen la Pilko atingis la rompita glitveturilon!';
 decor = 'La Pilko nur devis iri malsupren malgranda monteto. Tuj kiam la Pilko komencis malsupreniri, forta vento kaptis ghin kaj {@ walk road3|porti for} malproksime de Patro Kristnasko!';
}

room {
 nam = 'road3';
 title = 'Itinero';
 onenter = 'La pilko estis sur la vojeto! Nu, kio, li ne povas akiri al Patro Kistnasko kaj savi lin?';
 decor = 'Sed subite de donis estis flugita boakoj! Sakon pendis de cervo sela. La pilko legi la surskribon, ghi legis: "En la kazo de la alveno de beakoj legi". ^Pilko trankvile malfermis la sakon kaj legu la noton, kiu diris, ke ghi estas sufiĉe sela la boakoj kaj li kuregas de Patro Kristnasko.^^{@ walk lvl3_2| Rajdi la boakoj}';
}

room {
 nam = 'lvl3_2';
 title = 'Pri Patro la sleigh';
 onenter = 'Momenton! Kaj la Pilko estas jam pri Patro la sleigh. Sed la boakoj estis irita.';
 decor = function(s) 
 if have 'art' then 
 p 'Pilko piediris super al la sledo kaj prenis la sakon de la segho de la shoforo. Sub la sako rezultis esti Patro Kristnasko. ^^ - Dankon, bona homo! Vi savis ne nur la novan jaron, sed mi! Mi shatus demandi vin pri io. Chu vi hazarde trovas unu la grandeco de la palmo kaj gravurita kun abio?^^ - Jes! Estas unu. ^^Mi donis al la scintilado al Patro Kristnasko. Li glitis en ghi de ero en la sledge la panelo, kaj la sledge iomete levighis de la tero.^^ - Nun sledge povas flugi! Sidi reen, mi helpos vin akiri hejmo.^^{@ walk end1| Sidi en la malantaua sidloko}';
 else 
 p 'Pilko piediris super al la sledo kaj prenis la sakon de la segho de la shoforo. Sub la sako rezultis esti Patro Kristnasko. ^^ - Dankon, bona homo! Vi savis ne nur la novan jaron, sed mi! Mi shatus demandi vin pri io. Chu vi hazarde trovas unu la grandeco de la palmo kaj gravurita kun abio? ^^ - Ne estas Avo frosto, ne vidis. Kio ghi estas? ^^ Estas tia afero, kiu povas devigi flugi la sledo, sed ĝi aspektas kiel shi estas perdita por chiam. Ni devos voki la kriz servoj, ĉar ni ne estos chi tie longe. Mi chiam portas regula vestoj nur en kazo, vi neniam scias...^^Do ni sidis en la sledo kaj atendis por savantoj. Baldaŭ ili trovis nin kaj portis min al la hospitalo, kiel mi estis tre malvarma, kaj Patro Kristnasko demandita preni lin al la urbo. Pli mi ne vidis lin, sed en la sekvanta tago, kiam mi estis che hejmo, mi vidis Kristnaskan donacon sub la arbo. Ankorau, Patro Kristnasko lasis min donaco. Ghi shajnas ke pro la akcidento li estis malfrue por unu tago, tio estas, la donacoj chiuj estis atendanta por la nokto de la unua de januaro...';
 end;
 end;
};

room {
 nam = 'end1';
 title = 'La fino';
 decor = 'Baldau mi estis che mia sojlo. Patro Kristnasko mansalutis al mi, deziris al mi felichan novan jaron kaj flugis for ie en la distanco. Mi eniris la domon. Sub la Kristnaska arbo, mi vidis donacon! ^^^"Sufichas kredi en Patro Kristnasko kaj li estos ekzistas..." © Vivo';
}
