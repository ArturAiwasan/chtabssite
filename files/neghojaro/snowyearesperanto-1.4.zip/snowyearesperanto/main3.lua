--$Name: Negho jaro: Esperanto$
--$Author: Артур А.$
--$Version: 1.4$

-- Precipe sur ЗОК 2019!

-- INSTEAD версия:
-- INSTEAD 3.2.2

 dofile ('esperanto-main.lua')

 xact.walk = walk  

require "fmt"
require "theme"


function init()

end;

room {
	
	nam = 'main';
	title = 'Menuo|Menu';
	decor = (fmt.c'{@ walk esperantomain| ^^^^^^^^^^^^^Por komenci}');
	enter = function(s)
	theme.set("scr.gfx.bg", "theme/bg.png");
	end;
}
