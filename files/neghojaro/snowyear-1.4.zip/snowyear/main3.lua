--$Name: Снежный год$
--$Author: Артур А.$
--$Version: 1.4$

-- Специально на ЗОК 2019!

-- INSTEAD версия:
-- INSTEAD 3.2.2

 dofile ('ru-main.lua')

 xact.walk = walk  

require "fmt"
require "theme"

 
function init()

end;

room {
	
	nam = 'main';
	title = 'Меню|Menu';
	decor = (fmt.c'{@ walk rumain| ^^^^^^^^^^^^^Начать}');
	enter = function(s)
	theme.set("scr.gfx.bg", "theme/bg.png");
	end;
}
